﻿using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows.Forms;
using System;
using System.Drawing;
using System.Timers;
using System.Linq;
using POSSYSTEMFINAL;


public partial class ProductCatalog : Form
{
    private ShoppingCart shoppingCart;
    private List<Vehicle> vehicles = new List<Vehicle>();
    private List<int> deletedVehicleIds = new List<int>(); // Track deleted vehicle IDs
    private string onlineConnectionString = @"Data Source=34.105.253.161;Initial Catalog=Cardearlership;Persist Security Info=True;User ID=sqlserver;Password=Faris200510;Encrypt=False;";
    private string offlineConnectionString = @"Data Source=(localdb)\Local;Initial Catalog=CarDealer;Integrated Security=True;Encrypt=false;";
    private System.Timers.Timer syncTimer;
    private List<Vehicle> cartItems = new List<Vehicle>();
    private QrScanner qrScanner; // Added QrScanner instance

    public ProductCatalog()
    {
        InitializeComponent();
        try
        {
            PopulateVehiclesFromDatabase();
            DisplayVehicles();
            InitializeSyncTimer();
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Error: {ex.Message}");
        }
        shoppingCart = new ShoppingCart(offlineConnectionString);

        qrScanner = new QrScanner(); //  QrScanner

        qrScanner.QrCodeScanned += HandleQrCodeScanned;
    }

    private void HandleQrCodeScanned(string qrData)
    {
        Vehicle vehicle = FindVehicleById(qrData);
        if (vehicle != null)
        {
            shoppingCart.AddToCart(vehicle);
        }
    }

    private Vehicle FindVehicleById(string id)
    {
        return vehicles.FirstOrDefault(v => v.Id.ToString() == id);
    }

    private void PopulateVehiclesFromDatabase(string brand = "", string vehicleType = "")
    {
        using (SqlConnection connection = new SqlConnection(offlineConnectionString))
        {
            string query = "SELECT Type, Brand, Year, Price, Color, Mileage_, Model, ImagePath FROM Vehicle WHERE 1=1";
            if (!string.IsNullOrWhiteSpace(brand))
                query += $" AND Brand = '{brand}'";
            if (!string.IsNullOrWhiteSpace(vehicleType))
                query += $" AND Type = '{vehicleType}'";

            SqlCommand command = new SqlCommand(query, connection);
            connection.Open();
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                string type = reader.GetString(0);
                string model = reader.GetString(1);
                int year = reader.GetInt32(2);
                decimal price = reader.GetDecimal(3);
                string imagePath = reader.GetString(7); // ImagePath is at index 7
                vehicles.Add(new Vehicle(type, model, year, price, imagePath));
            }
            reader.Close();
        }
    }

    private void DisplayVehicles()
    {
        flowLayoutPanel.Controls.Clear();
        foreach (var vehicle in vehicles)
        {
            try
            {
                PictureBox pictureBox = new PictureBox();
                pictureBox.Image = Image.FromFile(vehicle.ImagePath);
                pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
                pictureBox.Width = 150;
                pictureBox.Height = 100;
                pictureBox.Click += (sender, e) => AddToCart(vehicle);

                Label label = new Label();
                label.Text = $"{vehicle.Type} {vehicle.Model} ({vehicle.Year}) - ${vehicle.Price}";

                flowLayoutPanel.Controls.Add(pictureBox);
                flowLayoutPanel.Controls.Add(label);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading image: {ex.Message}");
            }
        }
    }

    private void btnSearch_Click(object sender, EventArgs e)
    {
        string brand = txtBrand.Text.Trim();
        string type = txtType.Text.Trim();
        try
        {
            vehicles.Clear();
            PopulateVehiclesFromDatabase(brand, type);
            DisplayVehicles();
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Error searching: {ex.Message}");
        }
    }

    private void btnClear_Click(object sender, EventArgs e)
    {
        txtBrand.Text = "";
        txtType.Text = "";
        vehicles.Clear();
        PopulateVehiclesFromDatabase();
        DisplayVehicles();
    }

    private void button1_Click(object sender, EventArgs e)
    {

    }

    private void flowLayoutPanel_Paint(object sender, PaintEventArgs e)
    {

    }

    private void txtBrand_TextChanged(object sender, EventArgs e)
    {

    }

    private void flowLayoutPanel_Paint_1(object sender, PaintEventArgs e)
    {

    }

    private bool IsDatabaseOnline()
    {
        try
        {
            using (SqlConnection connection = new SqlConnection(onlineConnectionString))
            {
                connection.Open();
                return true;
            }
        }
        catch
        {
            return false;
        }
    }

    private void AddToCart(Vehicle vehicle)
    {
        shoppingCart.AddToCart(vehicle);
        MessageBox.Show($"Added {vehicle.Type} {vehicle.Model} to cart.");
    }


    private void InitializeSyncTimer()
    {
        syncTimer = new System.Timers.Timer(3600000); // Sync every hour
        syncTimer.Elapsed += OnTimedEvent;
        syncTimer.AutoReset = true;
        syncTimer.Enabled = true;
    }

    private void OnTimedEvent(Object source, ElapsedEventArgs e)
    {
        SyncDataToOnline();
    }

    private void SyncDataToOnline()
    {
        if (!IsDatabaseOnline()) return;

        try
        {
            using (SqlConnection offlineConnection = new SqlConnection(offlineConnectionString))
            {
                offlineConnection.Open();
                string query = "SELECT * FROM Vehicle"; // Adjust the query based on your schema
                SqlCommand command = new SqlCommand(query, offlineConnection);
                SqlDataReader reader = command.ExecuteReader();
                List<int> syncedIds = new List<int>();
                using (SqlConnection onlineConnection = new SqlConnection(onlineConnectionString))
                {
                    onlineConnection.Open();
                    while (reader.Read())
                    {
                        // Example: Update online database with data from offline database
                        // Adjust the query and parameters based on your schema
                        string updateQuery = "UPDATE Vehicle SET Brand = @Brand WHERE Id = @Id";
                        SqlCommand updateCommand = new SqlCommand(updateQuery, onlineConnection);
                        updateCommand.Parameters.AddWithValue("@Id", reader["Id"]);
                        updateCommand.Parameters.AddWithValue("@Brand", reader["Brand"]);
                        updateCommand.ExecuteNonQuery();
                        syncedIds.Add((int)reader["Id"]);
                    }

                    // Handle deletions
                    foreach (int id in deletedVehicleIds)
                    {
                        string deleteQuery = "DELETE FROM Vehicle WHERE Id = @Id";
                        SqlCommand deleteCommand = new SqlCommand(deleteQuery, onlineConnection);
                        deleteCommand.Parameters.AddWithValue("@Id", id);
                        deleteCommand.ExecuteNonQuery();
                    }
                    deletedVehicleIds.Clear(); // Clear the list after syncing deletions
                }
                reader.Close();

                foreach (int id in syncedIds)
                {
                    string deleteQuery = "DELETE FROM Vehicle WHERE Id = @Id";
                    SqlCommand deleteCommand = new SqlCommand(deleteQuery, offlineConnection);
                    deleteCommand.Parameters.AddWithValue("@Id", id);
                    deleteCommand.ExecuteNonQuery();
                }
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Error syncing data: {ex.Message}");
        }
    }

    private void button1_Click_2(object sender, EventArgs e)
    {
        // Show the shoppingCart form
        shoppingCart.Show();
    }


}


public class Vehicle
{
    public int Id { get; set; }
    public string Type { get; set; }
    public string Model { get; set; }
    public int Year { get; set; }
    public decimal Price { get; set; }
    public string ImagePath { get; set; }

    public Vehicle(string type, string model, int year, decimal price, string imagePath)
    {
        Type = type;
        Model = model;
        Year = year;
        Price = price;
        ImagePath = imagePath;
    }
}
