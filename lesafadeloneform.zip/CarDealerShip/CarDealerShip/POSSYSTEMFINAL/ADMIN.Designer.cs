﻿namespace POSSYSTEMFINAL
{
    partial class ADMIN
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ADMIN));
            this.Financebtn = new POSSYSTEMFINAL.UI_Designs.Roundbuttons();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.roundbuttons1 = new POSSYSTEMFINAL.UI_Designs.Roundbuttons();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.ManageVehiclesbtn = new POSSYSTEMFINAL.UI_Designs.Roundbuttons();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.ManageCustomersbtn = new POSSYSTEMFINAL.UI_Designs.Roundbuttons();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // Financebtn
            // 
            this.Financebtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(17)))), ((int)(((byte)(224)))));
            this.Financebtn.FlatAppearance.BorderSize = 0;
            this.Financebtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Financebtn.Font = new System.Drawing.Font("Monospac821 BT", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Financebtn.ForeColor = System.Drawing.Color.Black;
            this.Financebtn.Location = new System.Drawing.Point(213, 28);
            this.Financebtn.Name = "Financebtn";
            this.Financebtn.Size = new System.Drawing.Size(543, 77);
            this.Financebtn.TabIndex = 4;
            this.Financebtn.Text = "Finances";
            this.Financebtn.UseVisualStyleBackColor = false;
            this.Financebtn.Click += new System.EventHandler(this.Financebtn_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(36, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(128, 116);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // roundbuttons1
            // 
            this.roundbuttons1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(17)))), ((int)(((byte)(224)))));
            this.roundbuttons1.FlatAppearance.BorderSize = 0;
            this.roundbuttons1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.roundbuttons1.Font = new System.Drawing.Font("Monospac821 BT", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.roundbuttons1.ForeColor = System.Drawing.Color.Black;
            this.roundbuttons1.Location = new System.Drawing.Point(213, 148);
            this.roundbuttons1.Name = "roundbuttons1";
            this.roundbuttons1.Size = new System.Drawing.Size(543, 77);
            this.roundbuttons1.TabIndex = 6;
            this.roundbuttons1.Text = "View/Manage Employees";
            this.roundbuttons1.UseVisualStyleBackColor = false;
            this.roundbuttons1.Click += new System.EventHandler(this.roundbuttons1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(36, 148);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(128, 93);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 7;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(36, 275);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(128, 93);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 8;
            this.pictureBox3.TabStop = false;
            // 
            // ManageVehiclesbtn
            // 
            this.ManageVehiclesbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(17)))), ((int)(((byte)(224)))));
            this.ManageVehiclesbtn.FlatAppearance.BorderSize = 0;
            this.ManageVehiclesbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ManageVehiclesbtn.Font = new System.Drawing.Font("Monospac821 BT", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ManageVehiclesbtn.ForeColor = System.Drawing.Color.Black;
            this.ManageVehiclesbtn.Location = new System.Drawing.Point(213, 275);
            this.ManageVehiclesbtn.Name = "ManageVehiclesbtn";
            this.ManageVehiclesbtn.Size = new System.Drawing.Size(543, 77);
            this.ManageVehiclesbtn.TabIndex = 9;
            this.ManageVehiclesbtn.Text = "View/Manage Vehicles";
            this.ManageVehiclesbtn.UseVisualStyleBackColor = false;
            this.ManageVehiclesbtn.Click += new System.EventHandler(this.roundbuttons2_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(36, 394);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(128, 93);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 10;
            this.pictureBox4.TabStop = false;
            // 
            // ManageCustomersbtn
            // 
            this.ManageCustomersbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(17)))), ((int)(((byte)(224)))));
            this.ManageCustomersbtn.FlatAppearance.BorderSize = 0;
            this.ManageCustomersbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ManageCustomersbtn.Font = new System.Drawing.Font("Monospac821 BT", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ManageCustomersbtn.ForeColor = System.Drawing.Color.Black;
            this.ManageCustomersbtn.Location = new System.Drawing.Point(213, 394);
            this.ManageCustomersbtn.Name = "ManageCustomersbtn";
            this.ManageCustomersbtn.Size = new System.Drawing.Size(543, 77);
            this.ManageCustomersbtn.TabIndex = 11;
            this.ManageCustomersbtn.Text = "View/Manage Customers";
            this.ManageCustomersbtn.UseVisualStyleBackColor = false;
            this.ManageCustomersbtn.Click += new System.EventHandler(this.ManageCustomersbtn_Click);
            // 
            // ADMIN
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.ClientSize = new System.Drawing.Size(800, 499);
            this.Controls.Add(this.ManageCustomersbtn);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.ManageVehiclesbtn);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.roundbuttons1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Financebtn);
            this.Name = "ADMIN";
            this.Text = "ADMIN";
            this.Load += new System.EventHandler(this.ADMIN_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private UI_Designs.Roundbuttons Financebtn;
        private System.Windows.Forms.PictureBox pictureBox1;
        private UI_Designs.Roundbuttons roundbuttons1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private UI_Designs.Roundbuttons ManageVehiclesbtn;
        private System.Windows.Forms.PictureBox pictureBox4;
        private UI_Designs.Roundbuttons ManageCustomersbtn;
    }
}