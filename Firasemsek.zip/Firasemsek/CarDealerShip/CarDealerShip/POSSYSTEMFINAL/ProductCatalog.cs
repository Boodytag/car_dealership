﻿using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows.Forms;
using System;
using System.Drawing;
using System.Timers;  // Added for Timer
using POSSYSTEMFINAL;

public partial class ProductCatalog : Form
{
    private List<Vehicle> vehicles = new List<Vehicle>();
    private string connectionString;
    private string onlineConnectionString = @"Data Source=34.105.253.161;Initial Catalog=Cardearlership;Persist Security Info=True;User ID=sqlserver;Password=Faris200510;Encrypt=False;"; // Initialize with actual online DB connection string
    private string offlineConnectionString = @"Data Source=(localdb)\Local;Initial Catalog=master;Integrated Security=True;Encrypt=True;Trust Server Certificate=True"; // Initialize with actual offline DB connection string
    private System.Timers.Timer syncTimer;
    private List<Vehicle> offlineVehicles = new List<Vehicle>();

    public ProductCatalog(string connectionString)
    {
        this.connectionString = connectionString;
        this.offlineConnectionString = @"Data Source=34.105.253.161;Initial Catalog=Cardearlership;Persist Security Info=True;User ID=sqlserver;Password=Faris200510;Encrypt=False;"; // Initialize with actual offline DB connection string
        this.onlineConnectionString = @"Data Source=(localdb)\Local;Initial Catalog=master;Integrated Security=True;Encrypt=True;Trust Server Certificate=True"; // Initialize with actual online DB connection string
        InitializeComponent();
        try
        {
            PopulateVehiclesFromDatabase();
            DisplayVehicles();
            InitializeSyncTimer();
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Error: {ex.Message}");
        }
    }
    private bool IsDatabaseOnline()
    {
        try
        {
            using (SqlConnection connection = new SqlConnection(onlineConnectionString))
            {
                connection.Open();
                return true;
            }
        }
        catch
        {
            return false;
        }
    }

    private void AddToCart(Vehicle vehicle)
    {
        if (IsDatabaseOnline())
        {
            // Logic to handle online scenario
            MessageBox.Show($"Added {vehicle.Make} {vehicle.Model} to cart.");
        }
        else
        {
            // Handle offline scenario by adding to a local list
            offlineVehicles.Add(vehicle);
            MessageBox.Show($"Database is offline. Added {vehicle.Make} {vehicle.Model} to offline cart.");
        }
    }

    private void InitializeSyncTimer()
    {
        syncTimer = new System.Timers.Timer(3600000); // Sync every hour
        syncTimer.Elapsed += OnTimedEvent;
        syncTimer.AutoReset = true;
        syncTimer.Enabled = true;
    }

    private void OnTimedEvent(Object source, ElapsedEventArgs e)
    {
        SyncDataToOnline();
    }

    private void SyncDataToOnline()
    {
        if (!IsDatabaseOnline()) return;

        try
        {
            using (SqlConnection offlineConnection = new SqlConnection(offlineConnectionString))
            {
                offlineConnection.Open();
                string query = "SELECT * FROM Vehicle"; // Adjust the query based on your schema
                SqlCommand command = new SqlCommand(query, offlineConnection);
                SqlDataReader reader = command.ExecuteReader();
                List<int> syncedIds = new List<int>();
                using (SqlConnection onlineConnection = new SqlConnection(onlineConnectionString))
                {
                    onlineConnection.Open();
                    while (reader.Read())
                    {
                        // Example: Update online database with data from offline database
                        // Adjust the query and parameters based on your schema
                        string updateQuery = "UPDATE Vehicle SET Brand = @Brand WHERE Id = @Id";
                        SqlCommand updateCommand = new SqlCommand(updateQuery, onlineConnection);
                        updateCommand.Parameters.AddWithValue("@Id", reader["Id"]);
                        updateCommand.Parameters.AddWithValue("@Brand", reader["Brand"]);
                        updateCommand.ExecuteNonQuery();
                        syncedIds.Add((int)reader["Id"]);
                    }
                }
                reader.Close();
                // Delete synced data from offline database
                foreach (int id in syncedIds)
                {
                    string deleteQuery = "DELETE FROM Vehicle WHERE Id = @Id";
                    SqlCommand deleteCommand = new SqlCommand(deleteQuery, offlineConnection);
                    deleteCommand.Parameters.AddWithValue("@Id", id);
                    deleteCommand.ExecuteNonQuery();
                }
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Error syncing data: {ex.Message}");
        }
    }
    private void PopulateVehiclesFromDatabase(string brand = "", string type = "")
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            string query = "SELECT Type, Brand, Year, Price, Color, Mileage_, Model, ImagePath FROM Vehicle WHERE 1=1";
            if (!string.IsNullOrWhiteSpace(brand))
                query += $" AND Brand = '{brand}'";
            if (!string.IsNullOrWhiteSpace(type))
                query += $" AND Type = '{type}'";

            SqlCommand command = new SqlCommand(query, connection);
            connection.Open();
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                string make = reader.GetString(0);
                string model = reader.GetString(1);
                int year = reader.GetInt32(2);
                decimal price = reader.GetDecimal(3);
                string imagePath = reader.GetString(7); // ImagePath is at index 7
                vehicles.Add(new Vehicle(make, model, year, price, imagePath));
            }
            reader.Close();
        }
    }

    private void DisplayVehicles()
    {
        flowLayoutPanel.Controls.Clear();
        foreach (var vehicle in vehicles)
        {
            try
            {
                PictureBox pictureBox = new PictureBox();
                pictureBox.Image = Image.FromFile(vehicle.ImagePath);
                pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
                pictureBox.Width = 150;
                pictureBox.Height = 100;
                pictureBox.Click += (sender, e) => AddToCart(vehicle);

                Label label = new Label();
                label.Text = $"{vehicle.Make} {vehicle.Model} ({vehicle.Year}) - ${vehicle.Price}";

                flowLayoutPanel.Controls.Add(pictureBox);
                flowLayoutPanel.Controls.Add(label);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading image: {ex.Message}");
            }
        }
    }

    private void btnSearch_Click(object sender, EventArgs e)
    {
        string brand = txtBrand.Text.Trim();
        string type = txtType.Text.Trim();
        try
        {
            vehicles.Clear();
            PopulateVehiclesFromDatabase(brand, type);
            DisplayVehicles();
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Error searching: {ex.Message}");
        }
    }

    private void btnClear_Click(object sender, EventArgs e)
    {
        txtBrand.Text = "";
        txtType.Text = "";
        vehicles.Clear();
        PopulateVehiclesFromDatabase();
        DisplayVehicles();
    }

    private void button1_Click(object sender, EventArgs e)
    {

    }

    private void flowLayoutPanel_Paint(object sender, PaintEventArgs e)
    {

    }

    private void button1_Click_1(object sender, EventArgs e)
    {
        ShoppingCart shopping = new ShoppingCart(connectionString);
        shopping.Show();
    }

    private void txtBrand_TextChanged(object sender, EventArgs e)
    {

    }

    private void flowLayoutPanel_Paint_1(object sender, PaintEventArgs e)
    {

    }
}


public class Vehicle
{
    public string Make { get; set; }
    public string Model { get; set; }
    public int Year { get; set; }
    public decimal Price { get; set; }
    public string ImagePath { get; set; }

    public Vehicle(string make, string model, int year, decimal price, string imagePath)
    {
        Make = make;
        Model = model;
        Year = year;
        Price = price;
        ImagePath = imagePath;
    }
}
